"use client"

import prisma from "../src/config/database"

export default function SyntheticV0PageForDeployment() {
  return <prisma />
}